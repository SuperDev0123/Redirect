// exports.config = {
//     connectionLimit: 10,
//     user: "root",
//     host: "localhost",
//     password: "root",
//     // host: "82.180.163.126",
//     // password: "xKfjH6BtKzMGs7un",
//     database: "fencingone",
//     multipleStatements: true,
// }

exports.config = {
    connectionLimit: 10,
    user: "fencingone",
    host: "92.204.219.243",
    password: "Fencing0ne!",
    // host: "82.180.163.126",
    // password: "xKfjH6BtKzMGs7un",
    database: "xview",
    multipleStatements: true,
}